namespace Platformer.Components
{
    public class Enemy
    {
        public float Speed = 100;
        public float TimeLeft = 1.0f;
    }
}