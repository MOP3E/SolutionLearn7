﻿using Microsoft.Xna.Framework;

namespace Pong.GameObjects
{
    public class Ball : GameObject
    {
        public Vector2 Velocity;
    }
}