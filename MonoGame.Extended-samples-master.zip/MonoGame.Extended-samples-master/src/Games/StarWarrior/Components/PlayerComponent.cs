﻿namespace StarWarrior.Components
{
    public class PlayerComponent
    {
    }
}