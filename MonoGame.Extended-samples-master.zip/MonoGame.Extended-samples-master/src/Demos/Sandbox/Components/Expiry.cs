﻿namespace Sandbox.Components
{
    public class Expiry
    {
        public Expiry(float timeRemaining)
        {
            TimeRemaining = timeRemaining;
        }

        public float TimeRemaining;
    }
}