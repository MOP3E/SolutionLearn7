﻿using Microsoft.Xna.Framework;

namespace Sandbox.Components
{
    public class Raindrop
    {
        public Vector2 Velocity;
        public float Size = 3;
    }
}